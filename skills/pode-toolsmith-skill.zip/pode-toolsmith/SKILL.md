---
name: pode-toolsmith
description: Design, implement, and validate production-grade PowerShell tools using Pode, Pode.Web, and Podex (htmx+Mustache+Tailwind), including security, caching, OpenAPI, and testable structure.
metadata:
  short-description: Build advanced Pode-based tools end-to-end.
  maturity: production
  owner: you
  tags:
    - powershell
    - pode
    - pode-web
    - htmx
    - podex
    - openapi
    - security
---

# Pode Toolsmith Skill

## Purpose

Use this skill when the user wants to **build or enhance** an advanced tool using:

- **Pode** (server/API, middleware, auth, sessions, SSE/WebSockets, OpenAPI)
- **Pode.Web** (PowerShell-defined UI: pages, cards, tables, progress, themes)
- **Podex** (PowerShell/Pode backend + **htmx** frontend with Mustache+Tailwind, hypermedia-style)

This skill produces **runnable, minimal-surprise** results: a plan, a file structure, code artifacts, and validation steps.
It is designed to minimize follow-up questions by making safe defaults and by embedding verification gates.

## Explicit invocation

In Codex: run `$pode-toolsmith`.

## Inputs this skill expects

When the user provides these, use them; otherwise infer reasonable defaults and proceed:

1. **Tool type**
   - API/service, dashboard/UI, full-stack hypermedia app, or hybrid.
2. **Hosting target**
   - Local dev, Windows service, container, IIS/Azure Functions, LAN-accessible tool, etc.
3. **Auth / security requirement**
   - none, Basic over HTTPS, AD/LDAP, session auth, allowlisting, etc.
4. **Data source**
   - AD, SQL, REST, filesystem, RVTools, Veeam, etc.
5. **Non-functional requirements**
   - caching TTL, max users, response times, audit logs, test coverage, deployment constraints.

## Decision matrix (pick the stack)

Choose the **default** stack based on the user’s prompt and constraints:

1. **Choose Pode** when:
   - API-first, integrations, automation endpoints, OpenAPI docs, background tasks, SSE/WebSockets.
2. **Choose Pode.Web** when:
   - The UI should be built in PowerShell without writing HTML/CSS/JS, and needs tables/forms/charts/themes.
3. **Choose Podex** when:
   - The user wants a “modern web app feel” with minimal custom JS using **htmx** partial updates + templates,
     and accepts a small Node/Tailwind toolchain.

If the prompt fits more than one, pick one as default and provide a short “If you prefer X instead…” alternative.

## Operating procedure (no open ends)

### Step 1 — Clarify by inference (do not stall)

Extract requirements from the prompt. If details are missing, set defaults and continue.
Only ask questions if a missing detail blocks correctness or security (ex: auth model).

### Step 2 — Inspect the workspace

- Read `AGENTS.md` (if present) and project conventions.
- Scan existing server/app files, routes, modules, and assets.
- Detect whether Pode / Pode.Web / Podex is already in use.

### Step 3 — Validate environment (fast gate)

Run (or instruct to run) the included script:

- `scripts/Test-PodeToolingEnvironment.ps1`

It checks:
- PowerShell version
- Presence of Pode / Pode.Web (if required)
- Pester availability (for tests)
- Node/npm presence (only if Podex stack is selected)

If prerequisites are missing, provide exact install commands and proceed with the best viable subset.

### Step 4 — Design

Produce a high-level architecture that includes:

- Endpoints/routes
- Auth + middleware order (CORS/headers, auth, rate limiting, CSRF, sessions)
- Data flow (services layer)
- UI strategy (Pode.Web components OR htmx fragments)
- Caching strategy + invalidation
- Logging + correlation IDs
- Error model and HTTP status mapping
- Test strategy

### Step 5 — Implement incrementally with quality gates

Implement in slices. After each slice, ensure:

- Script loads without errors
- `Get-Command` confirms any referenced cmdlets exist
- Pester tests exist for the slice (or at least smoke tests)
- For UI: renders and updates without blocking UI (use background jobs/runspaces if needed)

### Step 6 — Deliverables

Always output:

- **File tree**
- **Run instructions**
- **Security notes**
- **Validation commands** (Pester, linting, smoke calls with curl/Invoke-RestMethod)
- **Next 3 improvements** that are likely valuable

## Reference guides included

- `references/Codex-Skills-Notes.md`
- `references/Pode-Patterns.md`
- `references/PodeWeb-Patterns.md`
- `references/Podex-Patterns.md`

## Templates included

- `assets/templates/PodeApiServer.ps1.mustache`
- `assets/templates/PodeWebApp.ps1.mustache`
- `assets/templates/PodexRoute.ps1.mustache`
- `assets/templates/appsettings.example.json`
- `assets/templates/README.template.md`

## Safety and correctness rules

1. **Never invent cmdlets**: verify with `Get-Command` and fall back to documented patterns.
2. **Security-first defaults**:
   - HTTPS for any authentication.
   - Prefer allowlisting and rate limiting for LAN tools.
   - Use sessions + CSRF for form-based flows.
3. **Predictable caching**:
   - Always document TTL, keys, and invalidation.
   - Provide a bypass for troubleshooting (e.g., `-NoCache`).
4. **No silent failure**:
   - Log errors with correlation IDs.
   - Return structured error bodies for APIs.
5. **Reproducibility**:
   - Pin module versions in docs.
   - Provide a clean “bootstrap” step.

---

## Quick-start (what to do when invoked)

1. Determine stack (Pode / Pode.Web / Podex) via decision matrix.
2. Run `Test-PodeToolingEnvironment`.
3. Scaffold with `New-PodeToolScaffold -Stack <Pode|PodeWeb|Podex> -Path <...>`.
4. Implement the smallest working feature.
5. Add tests and run `Invoke-PodeToolSelfTest`.
