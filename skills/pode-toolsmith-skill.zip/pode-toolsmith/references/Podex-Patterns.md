# Podex Patterns (Pode + htmx)

## When to choose Podex

- You want a modern, interactive UI with minimal JavaScript.
- You’re OK with templates and a Tailwind build step.

## Pattern: hypermedia endpoints

- Use routes that return:
  - full pages for initial load
  - partial fragments for htmx swaps
- Keep state on server (sessions) or encode into URLs/forms.

## Templates

- Mustache is logic-light:
  - do as much shaping as possible in PowerShell before rendering.
  - keep templates declarative.

## htmx conventions

- Prefer server-rendered fragments.
- Use out-of-band swaps for notifications/toasts.
- Use SSE for live updates where appropriate.
