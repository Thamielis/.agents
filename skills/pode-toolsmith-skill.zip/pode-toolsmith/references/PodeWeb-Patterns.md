# Pode.Web Patterns

## When to choose Pode.Web

- You want a dashboard quickly without writing HTML/CSS/JS.
- You need: pages, cards, tables, forms, charts, themes.

## Tables

- Drive tables from a scriptblock data source.
- Prefer pagination server-side for large datasets.
- Use auto-refresh only for lightweight calls; otherwise use background updates.

## Progress / long operations

- Avoid blocking UI while building large results:
  - compute in background (runspaces/job)
  - update UI progressively (progress components)

## Themes & custom CSS

- Start with built-in themes.
- Add a custom theme/CSS only after layout is stable.

## Common performance knobs

- Cache expensive data.
- Reduce object shape early (select only needed properties).
- Avoid repeated module imports per request.
