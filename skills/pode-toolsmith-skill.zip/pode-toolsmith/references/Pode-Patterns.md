# Pode Patterns (Production-leaning)

## Baseline server skeleton

- Use `Start-PodeServer` and declare endpoints explicitly.
- Separate concerns:
  - `src/Server/Server.ps1` (server bootstrap)
  - `src/Server/Endpoints.ps1`
  - `src/Routes/*.ps1`
  - `src/Services/*.ps1`
  - `src/Middleware/*.ps1`

## Security middleware order (typical)

1. Headers / CORS (so *all* responses include required headers)
2. Rate limiting / allowlisting
3. Sessions (if used)
4. CSRF (if forms)
5. Authentication
6. Authorization checks (roles/groups/scopes)
7. Routes

## Authentication choices

- Basic over HTTPS for quick internal tools.
- Windows AD / LDAP for enterprise environments.
- Session auth for web apps with login forms.

## OpenAPI

- For APIs: generate OpenAPI definitions and serve docs using viewers.
- Keep OpenAPI generation a first-class artifact.

## Real-time updates

- Use SSE for one-way server->client events (dashboards, progress).
- Use WebSockets for bi-directional interactions.

## Caching

- Cache expensive data (AD/SQL) with TTL + explicit invalidation.
- Ensure cache keys include the relevant query parameters.
